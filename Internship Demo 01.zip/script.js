body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
    text-align: center;
}

header {
    background: #ff6600;
    color: white;
    padding: 40px 20px;
}

h1 {
    font-size: 2.5em;
}

.cta-button {
    background: white;
    color: #ff6600;
    padding: 10px 20px;
    text-decoration: none;
    font-weight: bold;
    border-radius: 5px;
}

.services {
    padding: 40px 20px;
    background: white;
}

.service-item {
    display: inline-block;
    width: 30%;
    margin: 20px;
}

.service-item img {
    width: 100%;
    border-radius: 10px;
}

.contact {
    background: #333;
    color: white;
    padding: 40px 20px;
}

input, textarea, button {
    display: block;
    width: 80%;
    margin: 10px auto;
    padding: 10px;
    font-size: 1em;
}

button {
    background: #ff6600;
    color: white;
    border: none;
    cursor: pointer;
}

footer {
    background: #222;
    color: white;
    padding: 10px;
}
